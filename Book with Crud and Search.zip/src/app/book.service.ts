
import { Injectable } from '@angular/core';
import { Book } from './Book';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private httpClient: HttpClient) {

    this.getBookDetails().subscribe(data => this.bookList = data);
  }

  bookList: Array<Book> = [];

  url: string = "/assets/book.json";


  getBookDetails(): any {
    return this.httpClient.get<Book>(this.url);
  }//taking data from Json File


  deleteBook(id: number): void {
    let i = 0;
    for (let book of this.bookList) {
      if (book.id == id) {
        console.log("book id " + book.id);
        console.log(this.bookList.splice(i, 1));
      }
      i++;
    }

  }

  setBookDetails(book: Book) {
    this.bookList.push(book);

  }




 
  bookList1: Array<Book>
  search(data):any[]{
    this.bookList1=[]

    for (let book of this.bookList) {
      
      if (book.category == data.category1) {
        this.bookList1.push(book)
        
  }
} 
return (this.bookList1)
}
search1(data):any[]{
  this.bookList1=[]

  for (let book of this.bookList) {
    if (book.category== data.category) {
     
      this.bookList1.push(book)
      
}
}
return (this.bookList1)
}
}

