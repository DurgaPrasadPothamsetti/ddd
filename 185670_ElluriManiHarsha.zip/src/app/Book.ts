export class Book{
    id:string;
    name:string;
    price:string;
    category:string;
    }